import os
import speech_recognition as sr
import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import warnings
warnings.filterwarnings('ignore')


import xgboost as xgb

def load_models():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        model = xgb.XGBClassifier()
        model.load_model(os.path.join(script_dir, 'instrument_classifier.json'))

        vectorizer = joblib.load(os.path.join(script_dir, 'tfidf_vectorizer.pkl'))
        label_encoder = joblib.load(os.path.join(script_dir, 'label_encoder.pkl'))

        return model, vectorizer, label_encoder

    except Exception as e:
        print(f"\nERROR loading models: {e}")
        exit()


def recognize_speech():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("\nListening for instrument command...")
        r.adjust_for_ambient_noise(source, duration=1)
        try:
            audio = r.listen(source, timeout=5, phrase_time_limit=10)
            text = r.recognize_google(audio).lower()
            print(f"You said: {text}")
            return text
        except Exception as e:
            print(f"Speech recognition error: {e}")
            return None

def predict_instrument(text, model, vectorizer, label_encoder):
    try:
        features = vectorizer.transform([text])
        pred_proba = model.predict_proba(features)[0]
        pred_label = np.argmax(pred_proba)
        instrument = label_encoder.inverse_transform([pred_label])[0]
        confidence = pred_proba[pred_label]
        
        # Get top 3 predictions if confidence is low
        if confidence < 0.7:
            top3 = np.argsort(pred_proba)[-3:][::-1]
            alternatives = [
                f"{label_encoder.inverse_transform([i])[0]} ({pred_proba[i]:.1%})" 
                for i in top3
            ]
            print(f"Low confidence. Alternatives: {', '.join(alternatives)}")
            
        return instrument, confidence
        
    except Exception as e:
        print(f"Prediction error: {e}")
        return None, 0.0

if __name__ == "__main__":
    model, vectorizer, label_encoder = load_models()
    
    # Print available instrument classes
    print("\nAvailable instrument classes:")
    print(", ".join(label_encoder.classes_))
    
    while True:
        input("\nPress Enter to speak (or type 'quit' to exit)...")
        text = recognize_speech()
        
        if text and 'quit' not in text:
            instrument, confidence = predict_instrument(
                text, model, vectorizer, label_encoder
            )
            if instrument:
                print(f"\nPredicted Instrument: {instrument} (Confidence: {confidence:.1%})")
        else:
            print("Exiting...")
            break